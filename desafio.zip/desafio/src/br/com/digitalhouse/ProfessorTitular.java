package br.com.digitalhouse;

public class ProfessorTitular extends Professor {
    private String especialidade;

    public String getEspecialidade(){
        return especialidade;
    }

    public void setEspecialidade(String especialidade){
        this.especialidade = especialidade;
    }
}
