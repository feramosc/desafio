package br.com.digitalhouse;

public class ProfessorAdjunto extends Professor{
    private int qtdHorasMonitoria;
}
